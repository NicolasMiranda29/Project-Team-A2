function move_to_position(x_target, y_target, z_target)
    % Mueve el robot PPP al punto (x, y, z) deseado
    % Cinemática inversa directa para PPP tipo grúa

    % Convertir posición deseada a coordenadas articulares
    q1 = y_target; % eje Z moviéndose en Y
    q2 = x_target; % eje Y moviéndose en X
    q3 = z_target; % eje X moviéndose en Z

    q = [q1; q2; q3];

    % Visualizar
    figure('Color','k');
    plot_ppp(q, 'y');
    title(sprintf('Robot PPP movido a (%.2f, %.2f, %.2f)', x_target, y_target, z_target), 'Color','w');
end