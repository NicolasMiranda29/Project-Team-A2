clc; clear; close all;

% ================================
% 1. Definición del robot PPP (3 prismáticos)
% ================================
L1 = Link('a', 0, 'alpha', 0,     'sigma', 1, 'qlim', [0 2], 'modified');
L2 = Link('a', 0, 'alpha', pi/2, 'sigma', 1, 'qlim', [0 2], 'modified');
L3 = Link('a', 0, 'alpha', 0,     'sigma', 1, 'qlim', [0 2], 'modified');

PPP_robot = SerialLink([L1 L2 L3], 'name', 'PPP');

% ================================
% 2. Definición de puntos clave
% ================================
q_home   = [1.0 1.0 1.5];
q_pick   = [1.0 1.0 0.5];
q_lift   = [1.0 1.0 1.5];
q_move   = [2.0 2.0 1.5];
q_place  = [2.0 2.0 0.5];
q_return = [1.5 1.5 1.5];

% ================================
% 3. Interpolación de trayectoria
% ================================
steps = 20;
traj = [...
    jtraj(q_home, q_pick, steps);
    jtraj(q_pick, q_lift, steps);
    jtraj(q_lift, q_move, steps);
    jtraj(q_move, q_place, steps);
    jtraj(q_place, q_return, steps)
];

% ================================
% 4. Calcular posiciones del TCP
% ================================
tcp_path = zeros(size(traj,1), 3);
for i = 1:size(traj,1)
    T = PPP_robot.fkine(traj(i,:));
    tcp_path(i,:) = T.t';  % posición [x y z]
end

% ================================
% 5. Graficar trayectoria del TCP
% ================================
figure('Color','w');
plot3(tcp_path(:,1), tcp_path(:,2), tcp_path(:,3), 'r-', 'LineWidth', 2);
hold on;
plot3(tcp_path(1,1), tcp_path(1,2), tcp_path(1,3), 'go', 'MarkerSize', 8, 'DisplayName','Inicio');
plot3(tcp_path(end,1), tcp_path(end,2), tcp_path(end,3), 'bo', 'MarkerSize', 8, 'DisplayName','Fin');
grid on;
xlabel('X (m)'); ylabel('Y (m)'); zlabel('Z (m)');
title('Trayectoria 3D del efector final (PPP Robot)');
legend('Trayectoria','Inicio','Fin');
axis equal;
view(135,30);